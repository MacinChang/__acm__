These are the testcases and reference solutions for the
11 problems posed in the 2012 NWERC programming contest:

A - Admiral
B - Beer Pressure
C - Cycling
D - Digital Clock
E - Edge Case
F - Foul Play
G - Guards
H - Hip To Be Square
I - Idol
J - Joint Venture
K - Key Insight

These testcases and reference solutions are provided as a
courtesy to all participants and other algorithmic programming
enthusiasts.

The reference implementations given are not exhaustive, some
jury solutions have been omitted from this collection.

In the unfortunate event that mistakes are found in any of the
problems, please let us know at chipcie.jury@ch.tudelft.nl.

However, in accordance with ICPC rules for the Regional contests
please note that the contest score is now final.

-- The 2012 NWERC Jury
